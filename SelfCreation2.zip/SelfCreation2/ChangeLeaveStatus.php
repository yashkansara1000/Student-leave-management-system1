<?php
    include './Connection.php';
    $id=$_GET['id'];
    $type=$_GET['type'];
    
    if($type=="accept"){
        $query="update tbl_leave set Status='Accepted' where leave_id=$id";
    }
    else {
        $query="update tbl_leave set Status='Rejected' where leave_id=$id";
    }
    
    mysqli_query($con, $query);
    header("Location: ViewLeaveRequest.php");
?>