<?php
    $con= mysqli_connect("localhost", "root", "", "sc2");
?>