<?php
    include_once './Connection.php';
    $query="select * from tbl_student order by Enrollment_No";
    $res= mysqli_query($con, $query);
?>
<html>
    <head>
        <link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <script src="JavaScript/jquery-3.3.1.min.js"></script>
        
    </head>
    <body>
        <div class="container jumbotron mt-3">
        <div class="row">
        <?php 
        while ($arr = mysqli_fetch_array($res)) {
            
        ?>
            <div class="card mt-3 ml-3" style="width: 350px">
                <div class="card-body">
                    <h4 class="card-title"><?php echo $arr[1].' '.$arr[2];?></h4>
                    <div class="form-inline">
                        <h6 class="card-title">Enrollment No: </h6><p class="card-text ml-4" style="margin-top: -12px"><?php echo $arr[3];?></p>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
        </div>
        </div>
        <div class="container">
    <div class="row">
        <div class='col-sm-6'>
            <input type='text' class="form-control" id='datetimepicker4' />
        </div>
        <script type="text/javascript">
            
            $(document).ready(function() {
                $("#datetimepicker4").keyup(function() {
                    var a=$(this).val().length;
                    if(a==4){
                        var s=String($(this).val());
                        s=s+"/";
                        $(this).val(s);
                    }
                });
            });
        </script>
    </div>
</div>
    </body>
</html> 