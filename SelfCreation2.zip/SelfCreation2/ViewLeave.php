<?php
    session_start();
    if(!isset($_SESSION['id'])){
        header("Location: Login.php");
    }
    $id=$_SESSION['id'];
    include './Connection.php';
    $res1= mysqli_query($con,"SELECT * from tbl_leave where Student_id=$id");
    $count= mysqli_num_rows($res1);
    
    if(isset($_GET['page']))
    {
        if($_GET['type']=="next"){
            $page=$_GET['page'];
            $page++;
            
            if($page> ceil(($count/5)))
            {
                $page=ceil(($count/5));
            }
        }
        else {
            $page=$_GET['page'];
            $page--;
            if($page<1)
            {
                $page=1;
            }
        }
        $i=($page*5)-5;
        $query="SELECT * from tbl_leave where Student_id=$id limit $i,5";                                    
    }
    else {
        $query="SELECT * from tbl_leave where Student_id=$id limit 0,5";
        $page=1;
    }
    $res= mysqli_query($con, $query);
?>
<html>
    <head>
        <link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <script src="JavaScript/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="JavaScript/ApplyLeave.js" type="text/javascript"></script>
    </head>
    <body style="background-color: gainsboro">
        <div class="jumbotron text-center" style="background-color: grey">
            <h1 style="margin-top: -30px;margin-bottom: 30px;color: black;">Leave Aplication</h1>
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"style="margin-bottom: -64px">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="ApplyLeave.php">Apply Leave</a></li>
                    <li class="nav-item active"><a class="nav-link">View Leaves</a></li>
                    
                    <li class="nav-item"><a class="nav-link" href="Logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
        
        <div class="container mt-3" style="background-color: gray">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <h3 class="mb-3">Leave Request</h3>
                        </div>
                        <div class="col-6">
                            <ul class="pagination justify-content-end">
                                <li class="page-item"><a class="page-link" href="ViewLeave.php?page=<?php echo $page; ?>&type=previous">Previous</a></li>
                                <li class="page-item active"><a class="page-link"><?php echo $page;?></a></li>
                                <li class="page-item"><a class="page-link" href="ViewLeave.php?page=<?php echo $page; ?>&type=next">Next</a></li>
                            </ul>
                        </div>
                    </div>
                    <table class="table table-striped">
                        <thead class="">
                            <tr>
                                <th style="width: 100px;background-color: maroon;color: white;">Sr No</th>
                                <th style="width: 200px;background-color: maroon;color: white;">Start Time</th>
                                <th style="width: 200px;background-color: maroon;color: white;">End Time</th>
                                <th style="width: 300px;background-color: maroon;color: white;">Reason</th>
                                <th style="background-color: maroon;color: white;">Applied On</th>
                                <th style="background-color: maroon;color: white;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $j=0;
                            while ($row = mysqli_fetch_row($res)) {
                                $j++;
                            ?>
                            <tr>
                                <td><?php echo $j;?></td>
                                <td><?php echo date("d-m-Y", strtotime($row[2])).' '.$row[4];?></td>
                                <td><?php echo date("d-m-Y", strtotime($row[3])).' '.$row[5];?></td>
                                <td><?php echo $row[6];?></td>
                                <td><?php echo date("d-m-Y", strtotime($row[7]));?></td>
                                <td><?php echo $row[8];?></td>
                            </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html>