<?php
    include './Connection.php';
    if(isset($_POST['field'])){
        $field=$_POST['field'];
        
        if($field==""){
            $query="select * from tbl_student order by Enrollment_No limit 0,5";
        }
        else {
            $query="select * from tbl_student where F_Name like '%$field%' or L_Name like '%$field%' or Enrollment_no like '%$field%' or Email_id like '%$field%' or Mobile_No like '%$field%' order by Enrollment_No";
        }
   
        $res= mysqli_query($con, $query);
        
        while ($row = mysqli_fetch_row($res)) {
            echo "<tr>";
            echo "<td>$row[3]</td>";
            echo "<td>$row[1]</td>";
            echo "<td>$row[2]</td>";
            echo "<td>$row[4]</td>";
            echo "<td>$row[5]</td>";
            echo "</tr>";
        }
    }
    if(isset($_POST['LeaveField'])){
        $field=$_POST['LeaveField'];
        
        if($field==""){
            $query="SELECT tbl_leave.*,tbl_student.Enrollment_no from tbl_leave INNER JOIN tbl_student ON tbl_leave.Student_id=tbl_student.Student_id limit 0,5";
        }
        else {
            $query="SELECT tbl_leave.*,tbl_student.Enrollment_no from tbl_leave INNER JOIN tbl_student ON tbl_leave.Student_id=tbl_student.Student_id where tbl_leave.From_Date like '%$field%' or tbl_leave.To_Date like '%$field%' or tbl_leave.From_Time like '%$field%' or tbl_leave.To_Time like '%$field%' or tbl_leave.Reason like '%$field%' or tbl_leave.Status like '%$field%' or tbl_leave.Applied_On like '%$field%' or tbl_Student.Enrollment_No like '%$field%'";
        }
   
        $res= mysqli_query($con, $query);
        
        while ($row = mysqli_fetch_row($res)) {
            echo "<tr>";
            echo "<td>$row[9]</td>";
            echo "<td>".date("d-m-Y", strtotime($row[2])).' '.$row[4]."</td>";
            echo "<td>".date("d-m-Y", strtotime($row[3])).' '.$row[5]."</td>";
            echo "<td>$row[6]</td>";
            echo "<td>".date("d-m-Y", strtotime($row[7]))."</td>";
            echo "<td>$row[8]</td>";
            echo "<td style='text-align: right;width: 200px'>";
                if($row[8]=="Pending"){
                    echo "<a href='ChangeLeaveStatus.php?id=$row[0]&type=accept' class='btn btn-outline-success btn-sm' role='Button'>Accept</a>";
                    echo "<a href='ChangeLeaveStatus.php?id=$row[0]&type=reject' class='btn btn-outline-danger btn-sm' role='Button'>Decline</a>";
                }
                else {}
            echo "</tr>";
        }
    }
?>