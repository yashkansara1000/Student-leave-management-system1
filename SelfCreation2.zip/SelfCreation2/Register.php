<html>
    <head>
        <link rel="stylesheet" type="text/css" href="CSS/Register.css"/>
        <script src="JavaScript/jquery-3.3.1.min.js"></script>
        <script src="JavaScript/Register.js"></script>
        <link href="bootstrap-4.3.1-dist/css/bootstrap.min.css">
    </head>
    <body>
        <form method="POST" enctype="multipart/form-data">
            <table>
                <tr>
                    <td id="text">File:</td> 
                    <td><input type="file" name="file" class="inputfile" required="true" accept=".csv" id="file">
                       <label for="file"><span id="nameLabel">Choose a File</span></label>
                    </td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="submit" value="Submit"></td>
                </tr>
            </table>
            
            
        </form>
    </body>
</html>

<?php
    if(isset($_POST['submit']))
    {
        $type=$_FILES['file']['type'];
        
    }
?>