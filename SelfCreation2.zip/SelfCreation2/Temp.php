<?php
    include './Connection.php';
    $res1= mysqli_query($con,"select * from tbl_student");
    $count= mysqli_num_rows($res1);
    
    if(isset($_GET['page']))
    {
        if($_GET['type']=="next"){
            $page=$_GET['page'];
            $page++;
            
            if($page> ceil(($count/2)))
            {
                $page=ceil(($count/2));
            }
        }
        else {
            $page=$_GET['page'];
            $page--;
            if($page<1)
            {
                $page=1;
            }
        }
        $i=($page*2)-2;
        $query="select * from tbl_student order by Enrollment_No limit $i,2";
                                    
    }
    else {
        $query="select * from tbl_student order by Enrollment_No limit 0,2";
        $page=1;
    }
?>

<html>
    <head>
        <link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <script src="JavaScript/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="JavaScript/ApplyLeave.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="jumbotron text-center mb-0">
            <h1 class="display-4 text-secondary" style="margin-top: -30px;margin-bottom: 30px">Leave Management System</h1>
            <nav class="navbar navbar-expand-sm navbar-expand-lg bg-dark navbar-dark mt-3" style="margin-bottom: -64px">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="AddStudents.php">Add Students</a></li>
                    <li class="nav-item active"><a class="nav-link">View Students</a></li>
                    <li class="nav-item"><a class="nav-link" href="ViewLeaveRequest.php">View Leave Request</a></li>
                    <li class="nav-item"><a class="nav-link" href="Logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
        <div class="container mt-3">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <h3 class="mb-3">Students</h3>
                        </div>
                        <div class="col-6">
                            <ul class="pagination justify-content-end">
                                <li class="page-item"><a class="page-link" href="Temp.php?page=<?php echo $page; ?>&type=previous">Previous</a></li>
                                <li class="page-item active"><a class="page-link"><?php echo $page;?></a></li>
                                <li class="page-item"><a class="page-link" href="Temp.php?page=<?php echo $page; ?>&type=next">Next</a></li>
                            </ul>
                        </div>
                    </div>
                    <table class="table table-striped">
                        <thead class="">
                            <tr>
                                <th>Enrollment Number</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email ID</th>
                                <th>Mobile Number</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                
                                
                              //  $query="select * from tbl_student order by Enrollment_No;";
                                $res= mysqli_query($con, $query);
                                
                                while ($row = mysqli_fetch_row($res)) {
                                    ?>
                            <tr>
                                <td><?php echo $row[3]?></td>
                                <td><?php echo $row[1]?></td>
                                <td><?php echo $row[2]?></td>
                                <td><?php echo $row[4]?></td>
                                <td><?php echo $row[5]?></td>
                            </tr>
                                    <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html>
