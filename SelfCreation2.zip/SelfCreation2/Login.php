<?php
    session_start();
?>
<html>
    <head>
        
		<script src="JavaScript/jquery-3.3.1.min.js" type="text/javascript"></script> 
		<link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">

    </head>
    <body style="background: gray">
        <div class="jumbotron-fluid">
        <div class="row" style="margin-top: 10%">
            <div class="col-4"></div>
            <div class="col-4">
                <div class="card" style="background-color: gainsboro; width: 100%;">
                    <div class="card-body">
                        <h1 class="text-center">Leave Aplication</h1>
                        <h2 class="text-center">Login</h2>
                        <hr><hr><center>
                        <form method="POST">
                            <div class="row">
                                <div class="form-inline pl-4 mt-4">
                                    <label for="uname" class="mr-sm-3">Username: </label>
                                    <input type="text" name="uname" class="form-control mb-0 mr-sm-5" style="width: 260px" id="uname" required="true">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-inline pl-4 mt-4">
                                    <label for="upass" class="mr-sm-3 ml-1">Password: </label>
                                    <input type="password" name="upass" class="form-control mb-0 mr-sm-5" style="width: 260px" id="upass" required="true">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-inline pl-4 mt-4">
                                    <input type="submit" name="submit" class="btn btn-secondary" value="Login" style="width: 360px">
                                </div>
                            </div>
                        </form></center>
                    </div>
                </div>
            </div>
            <div class="col-4"></div>
        </div>
        </div>
    </body>
</html>
<?php
    include './Connection.php';
    if(isset($_POST['submit'])){
        $uname=$_POST['uname'];
        $pas= $_POST['upass'];
        
        $query="select * from tbl_faculty where Username='$uname'";
        $res= mysqli_query($con, $query);
        if(mysqli_num_rows($res)){
            
            while ($row = mysqli_fetch_row($res)) {
                if($pas==$row[2]){
                    $_SESSION['id']=$row[0];
//                    header("Location: ViewStudents.php");
					echo "<script>location.href='ViewStudents.php';</script>";
                }
            }
        }
        else {
            $query="select * from tbl_student where Enrollment_No='$uname'";
            $res= mysqli_query($con, $query);
            if(mysqli_num_rows($res)){
                while ($row = mysqli_fetch_row($res)) {
                    if($pas==$row[6]){
                        $_SESSION['id']=$row[0];
                        //header("Location: ApplyLeave.php");
						echo "<script>location.href='ApplyLeave.php';</script>";
                    }
                }
            }
        }
    }
?>