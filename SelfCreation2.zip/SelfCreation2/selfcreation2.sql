-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2019 at 07:32 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `selfcreation2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faculty`
--

CREATE TABLE `tbl_faculty` (
  `id` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_faculty`
--

INSERT INTO `tbl_faculty` (`id`, `Username`, `Password`) VALUES
(1, 'PDV', 'b2c69627c3d11daa2bee24155c2456f3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leave`
--

CREATE TABLE `tbl_leave` (
  `leave_id` int(11) NOT NULL,
  `Student_id` int(11) NOT NULL,
  `From_Date` date NOT NULL,
  `To_Date` date NOT NULL,
  `From_Time` time NOT NULL,
  `To_Time` time NOT NULL,
  `Reason` varchar(250) NOT NULL,
  `Applied_On` date NOT NULL,
  `Status` varchar(15) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_leave`
--

INSERT INTO `tbl_leave` (`leave_id`, `Student_id`, `From_Date`, `To_Date`, `From_Time`, `To_Time`, `Reason`, `Applied_On`, `Status`) VALUES
(2, 5, '2019-03-01', '2019-03-02', '08:30:00', '15:30:00', 'Sick Leave', '2019-03-01', 'Accepted'),
(3, 13, '2019-03-03', '2019-03-05', '08:30:00', '15:30:00', 'Sick Leave', '2019-03-02', 'Rejected'),
(4, 15, '2019-03-12', '2019-03-13', '08:30:00', '15:30:00', 'Sick Leave', '2019-03-03', 'Rejected'),
(5, 18, '2019-03-06', '2019-03-06', '08:30:00', '15:30:00', 'mari marji', '2019-03-05', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `Student_id` int(11) NOT NULL,
  `F_Name` varchar(50) NOT NULL,
  `L_Name` varchar(50) NOT NULL,
  `Enrollment_no` varchar(15) NOT NULL,
  `Email_id` varchar(50) NOT NULL,
  `Mobile_no` varchar(10) NOT NULL,
  `Password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`Student_id`, `F_Name`, `L_Name`, `Enrollment_no`, `Email_id`, `Mobile_no`, `Password`) VALUES
(5, 'Parth', 'Vasoya', '201606100110127', '16mscit127@gmail.com', '1231231230', '6db012f325716c8c81d88f23dc0d3302'),
(6, 'Sushil', 'Yadav', '201606100110092', '16mscit092@gmail.com', '7897897890', '41edd4833f5892a500f53f7ae6761aed'),
(13, 'Mit', 'Desai', '201606100110112', '16mscit112@gmail.com', '1591591590', '20026e12a8a3f4660f00737ed996db87'),
(14, 'Vaibhav', 'Patel', '201606100110052', '16mscit052@gmail.com', '3213213210', 'e9ad559f94fba77b26482d168e0a6908'),
(15, 'Dharav', 'Patel', '201606100110001', '16mscit001@gmail.com', '9879879870', 'e8dfa887017d643d55d68a6fc9cb9e8c'),
(16, 'Mihir', 'Mehta', '201606100110002', '16mscit002@gmail.com', '4564654650', 'ceba5843e70d470a18b55e502b83a96c'),
(17, 'Yash', 'Kansara', '201606100110095', '16mscit095@gmail.com', '7537537560', 'ba6562f29d5e6f42cfbf557aa08eb687'),
(18, 'Yashraj', 'Pindi', '201606100110094', '16mscit094@gmail.com', '7537537561', '17065962fa7f14f7c102be2be36c2022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  ADD PRIMARY KEY (`leave_id`),
  ADD KEY `Student_id` (`Student_id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`Student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  MODIFY `leave_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `Student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  ADD CONSTRAINT `tbl_leave_ibfk_1` FOREIGN KEY (`Student_id`) REFERENCES `tbl_student` (`Student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
