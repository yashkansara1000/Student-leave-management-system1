<?php
    session_start();
    if(!isset($_SESSION['id'])){
        header("Location: Login.php");
    }
    include './Connection.php';
    $res1= mysqli_query($con,"SELECT tbl_leave.*,tbl_student.Enrollment_no from tbl_leave INNER JOIN tbl_student ON tbl_leave.Student_id=tbl_student.Student_id");
    $count= mysqli_num_rows($res1);
    
    if(isset($_GET['page']))
    {
        if($_GET['type']=="next"){
            $page=$_GET['page'];
            $page++;
            
            if($page> ceil(($count/5)))
            {
                $page=ceil(($count/5));
            }
        }
        else {
            $page=$_GET['page'];
            $page--;
            if($page<1)
            {
                $page=1;
            }
        }
        $i=($page*5)-5;
        $query="SELECT tbl_leave.*,tbl_student.Enrollment_no from tbl_leave INNER JOIN tbl_student ON tbl_leave.Student_id=tbl_student.Student_id order by tbl_leave.leave_id desc limit $i,5";                                    
    }
    else {
        $query="SELECT tbl_leave.*,tbl_student.Enrollment_no from tbl_leave INNER JOIN tbl_student ON tbl_leave.Student_id=tbl_student.Student_id order by tbl_Leave.Leave_Id desc limit 0,5";
        $page=1;
    }
    //$query="SELECT tbl_leave.*,tbl_student.Enrollment_no from tbl_leave INNER JOIN tbl_student ON tbl_leave.Student_id=tbl_student.Student_id";
    $res= mysqli_query($con, $query);
?>
<html>
    <head>
        <link href="fontawesome-free-5.7.1-web/css/all.min.css" type="text/css" rel="stylesheet">
        <link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <script src="JavaScript/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="JavaScript/ViewLeaveRequest.js" type="text/javascript"></script>
    </head>
    <body style="background-color: gainsboro">
        <div class="jumbotron text-center" style="background-color: grey">
            <h1 style="margin-top: -30px;margin-bottom: 30px;color: black;">Leave Aplication</h1>
            <nav class="navbar navbar-expand-sm navbar-expand-lg bg-dark navbar-dark mt-3" style="margin-bottom: -64px">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="ViewStudents.php">View Students</a></li>
                    <li class="nav-item active"><a class="nav-link">View Leave Request</a></li>
                    <li class="nav-item justify-content-end"><a class="nav-link" href="Logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
        
        <div class="container-fluid mt-3">
            <div class="card" style="background-color: gainsboro">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <h3 class="mb-3">Leave Request</h3>
                        </div>
                        <div class="col-4">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                                <input type="text" id="search" class="form-control" placeholder="Search">
                            </div>
                        </div>
                        <div class="col-4">
                            <ul class="pagination justify-content-end">
                                <li class="page-item"><a class="page-link" href="ViewLeaveRequest.php?page=<?php echo $page; ?>&type=previous">Previous</a></li>
                                <li class="page-item active"><a class="page-link"><?php echo $page;?></a></li>
                                <li class="page-item"><a class="page-link" href="ViewLeaveRequest.php?page=<?php echo $page; ?>&type=next">Next</a></li>
                            </ul>
                        </div>
                    </div>
                    <table class="table table-striped">
                        <thead class="">
                            <tr>
                                <th style="width: 200px;margin-right: -100px;background-color: maroon;color: white;">Enrollment Number</th>
                                <th style="width: 200px;background-color: maroon;color: white;">Start Date/Time</th>
                                <th style="width: 200px;background-color: maroon;color: white;">End Date/Time</th>
                                <th style="width: 250px;background-color: maroon;color: white;">Reason</th>
                                <th style="background-color: maroon;color: white;">Applied On</th>
                                <th style="background-color: maroon;color: white;">Status</th>
                                <th style="background-color: maroon;color: white;"></th>
                            </tr>
                        </thead>
                        <tbody id="tbody1">
                            <?php
                            while ($row = mysqli_fetch_row($res)) {
                                
                            ?>
                            <tr>
                                <td><?php echo $row[9];?></td>
                                <td><?php echo date("d-m-Y", strtotime($row[2])).' '.$row[4];?></td>
                                <td><?php echo date("d-m-Y", strtotime($row[3])).' '.$row[5];?></td>
                                <td><?php echo $row[6];?></td>
                                <td><?php echo date("d-m-Y", strtotime($row[7]));?></td>
                                <td><?php echo $row[8];?></td>
                                <td style="text-align: right;width: 200px">
                                    <?php
                                        if($row[8]=="Pending"){
                                            ?>
                                    <a href="ChangeLeaveStatus.php?id=<?php echo $row[0]; ?>&type=accept" class="btn btn-outline-success btn-sm" role="Button">Accept</a>
                                    <a href="ChangeLeaveStatus.php?id=<?php echo $row[0]; ?>&type=reject" class="btn btn-outline-danger btn-sm" role="Button">Decline</a>
                                            <?php
                                        }
                                        else {
                                            
                                        }
                                    
                                    ?>
                                </td>
                            </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html>