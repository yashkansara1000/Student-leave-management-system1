<?php
    session_start();
    if(!isset($_SESSION['id']))
    {
        header("Location:Login.php");
    }
    else {
    $id=$_SESSION['id'];    
}
?>
<html>
    <head>
        <link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <script src="JavaScript/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="JavaScript/ApplyLeave.js" type="text/javascript"></script>
    </head>
    <body style="background-color: gainsboro">
        <div class="jumbotron text-center" style="background-color: grey">
            <h1 style="margin-top: -30px;margin-bottom: 30px;color: black;">Leave Aplication</h1>
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"style="margin-bottom: -64px">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link">Home</a></li>
                    <li class="nav-item active"><a class="nav-link">Apply Leave</a></li>
                    <li class="nav-item"><a class="nav-link" href="ViewLeave.php">View Leaves</a></li>
                    
                    <li class="nav-item"><a class="nav-link" href="Logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
        
        <div class="container mt-3">
            <div class="card">
                <div class="card-body" style="height: 400px; background-color: gray">
                    <h2>Apply Leave</h2>
                    <form method="POST">
                        <div class="row">
                            <div class="form-inline pl-3 mt-4">
                                <label for="fromdate" class="mr-sm-3">From Date: </label>
                                <input type="date" name="fdate" class="form-control mb-0 mr-sm-5" id="fromdate" min='<?php echo date("Y-m-d"); ?>' required="true">
                                <label for="fromtime" class="mr-sm-3">Time: </label>
                                <input type="time" name="ftime" class="form-control mb-0 mr-sm-2" id="fromtime" min="08:30:00" max="15:30:00" required="true">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-inline  mt-4" style="padding-left: 35px">
                                <label for="todate" class="mr-sm-3">To Date: </label>
                                <input type="date" name="tdate" class="form-control mb-0 mr-sm-5" id="todate" required="true">
                                <label for="totime" class="mr-sm-3">Time: </label>
                                <input type="time" name="ttime" class="form-control mb-0 mr-sm-2" id="totime" min="08:30:00" max="15:30:00" required="true">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-inline  mt-4" style="padding-left: 40px">
                                <label for="reason" class="mr-sm-3">Reason: </label>
                                <textarea name="reason" class="form-control mb-0 mr-sm-5" rows="3" cols="30" id="reason" required="true"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-inline  mt-4" style="padding-left: 40px">
                                <input type="submit" name="submit" class="btn btn-success mr-sm-5">
                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    include './Connection.php';
    
    if(isset($_POST['submit'])){
        $fdate=$_POST['fdate'];
        $tdate=$_POST['tdate'];
        $ftime=$_POST['ftime'];
        $ttime=$_POST['ttime'];
        $reason=$_POST['reason'];
        $today= date("Y-m-d");
        
        $query="insert into tbl_leave(Student_Id,From_Date,To_Date,From_Time,To_Time,Reason,Applied_On) values($id,'$fdate','$tdate','$ftime','$ttime','$reason','$today')";
        mysqli_query($con, $query);
        
        echo "<script>alert('Leave Applied')</script>";
    }
?>