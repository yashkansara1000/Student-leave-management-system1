$(document).ready(function () {
    $("#search").keyup(function () {
        $.ajax({
            type: 'POST',
            url: "GetData.php",
            data: {field: $(this).val()},
            success: function (response) {
                $("#tbody").html(response);
            }
        });
    });
});