$(document).ready(function () {
    $("#search").keyup(function () {
        $.ajax({
            type: 'POST',
            url: "GetData.php",
            data: {LeaveField: $(this).val()},
            success: function (response) {
                $("#tbody1").html(response);
            }
        });
    });
});