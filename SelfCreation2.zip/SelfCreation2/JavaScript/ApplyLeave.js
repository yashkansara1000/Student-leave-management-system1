$(document).ready(function () {
    $("#fromdate").change(function () {
        var s=String($(this).val());
        $("#todate").attr("min",s);
    });
});