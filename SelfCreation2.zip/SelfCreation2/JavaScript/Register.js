$(document).ready(function () {
   $("#file").on("change",function (){
        var name=document.getElementById('file');
        $("#nameLabel").text(name.files.item(0).name);
    }); 
});